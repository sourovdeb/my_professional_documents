chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'DOM_ACTION') {
    try {
      let result;
      if (msg.action === 'click') {
        const el = document.querySelector(msg.selector);
        if (!el) { sendResponse({ error: 'Not found: ' + msg.selector }); return; }
        el.click(); result = { ok: true };
      } else if (msg.action === 'type') {
        const el = document.querySelector(msg.selector);
        if (!el) { sendResponse({ error: 'Not found: ' + msg.selector }); return; }
        el.focus(); el.value = msg.text;
        el.dispatchEvent(new Event('input', { bubbles:true }));
        result = { ok: true };
      } else if (msg.action === 'getText') {
        result = { text: document.body?.innerText?.slice(0,8000) };
      }
      sendResponse(result);
    } catch(e) { sendResponse({ error: e.message }); }
  }
  return true;
});
