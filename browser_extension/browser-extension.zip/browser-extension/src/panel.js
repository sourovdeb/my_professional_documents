const chat = document.getElementById('chat');
const input = document.getElementById('user-input');
const settingsPanel = document.getElementById('settings-panel');
const modelLabel = document.getElementById('model-label');

let conversationHistory = [];

// Load settings on open
chrome.storage.local.get(['provider','apiUrl','apiKey','model','systemPrompt'], cfg => {
  document.getElementById('s-provider').value = cfg.provider || 'ollama';
  document.getElementById('s-url').value = cfg.apiUrl || '';
  document.getElementById('s-key').value = cfg.apiKey || '';
  document.getElementById('s-model').value = cfg.model || '';
  document.getElementById('s-system').value = cfg.systemPrompt || '';
  modelLabel.textContent = cfg.model || 'no model set';
});

function addMsg(text, role) {
  const div = document.createElement('div');
  div.className = 'msg ' + (role === 'user' ? 'user' : role === 'error' ? 'error' : 'ai');
  div.textContent = text;
  chat.appendChild(div);
  chat.scrollTop = chat.scrollHeight;
  return div;
}

async function send(userText) {
  if (!userText.trim()) return;
  addMsg(userText, 'user');
  conversationHistory.push({ role: 'user', content: userText });

  const thinking = addMsg('…', 'ai');
  thinking.style.color = '#555';

  const res = await chrome.runtime.sendMessage({
    type: 'API_CALL',
    payload: { messages: conversationHistory }
  });

  thinking.remove();

  if (res?.error) {
    addMsg('Error: ' + res.error, 'error');
    return;
  }

  const reply = res.content || '(no response)';
  addMsg(reply, 'ai');
  conversationHistory.push({ role: 'assistant', content: reply });

  // Auto-execute JS blocks if reply contains ```javascript ... ```
  const jsMatch = reply.match(/```javascript\n([\s\S]+?)\n```/);
  if (jsMatch) {
    const code = jsMatch[1];
    chrome.runtime.sendMessage({ type: 'RUN_JS', code }, result => {
      if (result?.error) addMsg('JS Error: ' + result.error, 'error');
      else if (result?.result !== undefined) addMsg('Result: ' + JSON.stringify(result.result), 'ai');
    });
  }
}

document.getElementById('btn-send').addEventListener('click', () => {
  send(input.value);
  input.value = '';
});

input.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    send(input.value);
    input.value = '';
  }
});

document.getElementById('btn-page').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'GET_PAGE' }, data => {
    if (data?.error) { addMsg('Page error: ' + data.error, 'error'); return; }
    const ctx = `[Page: ${data.title}]\n${data.url}\n\n${data.text?.slice(0,2000)}`;
    input.value = ctx + '\n\n' + input.value;
  });
});

document.getElementById('btn-clear').addEventListener('click', () => {
  chat.innerHTML = '<div class="system-msg">Cleared.</div>';
  conversationHistory = [];
});

document.getElementById('btn-settings').addEventListener('click', () => {
  settingsPanel.style.display = settingsPanel.style.display === 'none' ? 'block' : 'none';
});

document.getElementById('btn-save-settings').addEventListener('click', () => {
  const data = {
    provider: document.getElementById('s-provider').value,
    apiUrl:   document.getElementById('s-url').value,
    apiKey:   document.getElementById('s-key').value,
    model:    document.getElementById('s-model').value,
    systemPrompt: document.getElementById('s-system').value
  };
  chrome.storage.local.set(data, () => {
    modelLabel.textContent = data.model || 'no model set';
    settingsPanel.style.display = 'none';
    addMsg('Settings saved. Provider: ' + data.provider + ' | Model: ' + data.model, 'ai');
  });
});

// Quick task buttons
document.querySelectorAll('.task-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    input.value = btn.dataset.task;
    send(input.value);
    input.value = '';
  });
});
